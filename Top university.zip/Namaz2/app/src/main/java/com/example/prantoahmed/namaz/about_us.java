package com.example.prantoahmed.namaz;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.TextView;

import java.net.URL;

public class about_us extends AppCompatActivity {

    private WebView  webView;
    private TextView textView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
        webView = (WebView) findViewById(R.id.facebook);
        textView1 = (TextView) findViewById(R.id.pranto);
        textView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                webView.loadUrl("https://www.facebook.com/prantoahmed900");
        }
        });


    }
}
