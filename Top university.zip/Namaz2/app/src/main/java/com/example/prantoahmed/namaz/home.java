package com.example.prantoahmed.namaz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.Button;

public class home extends AppCompatActivity implements View.OnClickListener {

    private CardView cardView1,cardView2,cardView3,cardView4,cardView5,cardView6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        cardView1 = (CardView) findViewById(R.id.fajar);
        cardView2 = (CardView) findViewById(R.id.dhuhor);
        cardView3 = (CardView) findViewById(R.id.asr);
        cardView4 = (CardView) findViewById(R.id.magrhib);
        cardView5 = (CardView) findViewById(R.id.isha2);
        cardView6 = (CardView) findViewById(R.id.about);
        cardView1.setOnClickListener(this);
        cardView2.setOnClickListener(this);
        cardView3.setOnClickListener(this);
        cardView4.setOnClickListener(this);
        cardView5.setOnClickListener(this);
        cardView6.setOnClickListener(this);

    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.fajar:

                Intent intent = new Intent(this, fajar.class);
                startActivity(intent);
                break;

            case R.id.dhuhor:

                Intent intent1 = new Intent(this, dhuhor.class);
                startActivity(intent1);
                break;

            case R.id.asr:

                Intent intent2 = new Intent(this, asr.class);
                startActivity(intent2);
                break;

            case R.id.magrhib:

                Intent intent3 = new Intent(this, magrhib.class);
                startActivity(intent3);
                break;

            case R.id.isha2:

                Intent intent4 = new Intent(this, isha.class);
                startActivity(intent4);
                break;

            case R.id.about:
                Intent intent5 = new Intent(this, others.class);
                startActivity(intent5);
                break;

            default:
                break;

        }
    }
}
