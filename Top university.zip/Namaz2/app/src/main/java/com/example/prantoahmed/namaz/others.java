package com.example.prantoahmed.namaz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;

public class others extends AppCompatActivity implements View.OnClickListener {
    private CardView cardView1,cardView2,cardView3,cardView4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_others);
        cardView1 = (CardView) findViewById(R.id.Tajbi);
        cardView2 = (CardView) findViewById(R.id.timing_of_namaz);
        cardView3 = (CardView) findViewById(R.id.surah);
        cardView4 = (CardView) findViewById(R.id.about_us);

        cardView1.setOnClickListener(this);
        cardView2.setOnClickListener(this);
        cardView3.setOnClickListener(this);
        cardView4.setOnClickListener(this);

    }
    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.Tajbi:

                Intent intent = new Intent(this, tajbi.class);
                startActivity(intent);
                break;

            case R.id.timing_of_namaz:

                Intent intent1 = new Intent(this, timing.class);
                startActivity(intent1);
                break;

            case R.id.surah:

                Intent intent2 = new Intent(this, surah.class);
                startActivity(intent2);
                break;

            case R.id.about_us:

                Intent intent3 = new Intent(this, about_us.class);
                startActivity(intent3);
                break;

            default:
                break;

        }
    }

}
